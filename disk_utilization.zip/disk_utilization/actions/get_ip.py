from st2common.runners.base_action import Action
import boto3
import re

class get_public_ip(Action):
    def run(self, hostname, credentials, region):
        status = False   #to check if we found server or not
        region =  'eu-west-1'
        public_ip = 'Hostname is invalid'  #if we found instance this will be replaced by public ip

        def get_region(hostname):
            input_string = hostname.lower()
            stripped_string = re.sub(r'\d*$', '', input_string)
            print(stripped_string)
            reg = stripped_string[-7:-5]
            area = stripped_string[-3]
            full_area = {
                    'w': 'west',
                    'e': 'east',
                    'n': 'north',
                    's': 'south'
                }
            area = full_area[area]
            az = stripped_string[-2]
            region = reg + '-' + area + '-' + az
            print(region)
            return region

        def extract_ip_address(input_string, credentials, region):
            ip_pattern = r'ip-(\d{1,3}-\d{1,3}-\d{1,3}-\d{1,3})'
            match = re.search(ip_pattern, input_string)
            if match:
                temp_ip =  match.group(1).replace('-', '.')
                try:
                    ec2_client = boto3.client("ec2", region_name=region, **credentials)
                    response = ec2_client.describe_instances(Filters=[{'Name': 'private-ip-address', 'Values': [temp_ip]}])
                    pub_ip = response['Reservations'][0]['Instances'][0]['PublicIpAddress']
                    return pub_ip

                except:
                    return temp_ip
            else:
                return None
        if hostname[0:2].lower() == 'ip':
            try:
                public_ip = extract_ip_address(hostname, credentials, region)
                if public_ip:
                    ec2_client = boto3.client("ec2", region_name=region, **credentials)
                    response = ec2_client.describe_instances(Filters=[{'Name': 'ip-address', 'Values': [public_ip]}])
                    os = response['Reservations'][0]['Instances'][0]['PlatformDetails']
                    if os == 'Linux/UNIX':
                        status = True
                        return status, public_ip
                    else:
                        public_ip = 'Host is not Linux'
                        status = False
                        return status, public_ip
            except:
                public_ip = 'Hostname is invalid'
                status = False
                return status, public_ip

        elif hostname[0:2].lower() == 'i-':
            try:
                ec2_client = boto3.client("ec2", region_name=region, **credentials)
                response = ec2_client.describe_instances(InstanceIds=[hostname])
                public_ip = response['Reservations'][0]['Instances'][0]['PublicIpAddress']
                os = response['Reservations'][0]['Instances'][0]['PlatformDetails']
                if os == 'Linux/UNIX':
                    status = True
                    return status, public_ip
                else:
                    public_ip = 'Host is not Linux'
                    status = False
                    return status, public_ip
            except:
                public_ip = 'Hostname or Region is invalid'
                status = False
                return status, public_ip

        elif hostname[0].lower() == "l":
            try:
                region = get_region(hostname)
                ec2_client = boto3.client("ec2", region_name=region, **credentials)
                response = ec2_client.describe_instances(Filters=[{'Name': 'tag:Name', 'Values': [hostname]}])
                public_ip = response['Reservations'][0]['Instances'][0]['PublicIpAddress']
                os = response['Reservations'][0]['Instances'][0]['PlatformDetails']
                if os == 'Linux/UNIX':
                    status = True
                    return status, public_ip
                else:
                    public_ip = 'Host is not Linux'
                    status = False
                    return status, public_ip

            except:
                public_ip = 'Hostname is invalid'
                status = False
                return status, public_ip

        elif hostname[0].lower() == "w":
            public_ip = 'Hostname is invalid or Windows'
            status = False
            return status, public_ip

        else:
            try:
                print(hostname)
                ec2_client = boto3.client("ec2", region_name=region, **credentials)
                response = ec2_client.describe_instances(Filters=[{'Name': 'tag:Name', 'Values': [hostname]}])
                public_ip = response['Reservations'][0]['Instances'][0]['PublicIpAddress']
                os = response['Reservations'][0]['Instances'][0]['PlatformDetails']
                if os == 'Linux/UNIX':
                    status = True
                    return status, public_ip
                else:
                    public_ip = 'Host is not Linux'
                    status = False
                    return status, public_ip

            except:
                public_ip = 'Hostname is invalid'
                status = False
                return status, public_ip

